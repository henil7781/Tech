const canvas = document.getElementById('gameCanvas');
        const ctx = canvas.getContext('2d');
        const startScreen = document.getElementById('startScreen');
        const gameOverScreen = document.getElementById('gameOverScreen');
        const scoreDisplay = document.getElementById('score');
        const finalScore = document.getElementById('finalScore');

        // Audio elements
        const bgMusic = document.getElementById('backgroundMusic');
        const jumpSound = document.getElementById('jumpSound');
        const collisionSound = document.getElementById('collisionSound');

        // Game images
        const images = {
            bird: new Image(),
            pipeTop: new Image(),
            pipeBottom: new Image(),
            background: new Image()
        };

        // Load images
        images.bird.src = 'img/airplane.png';
        images.pipeTop.src = 'img/building.png';
        images.pipeBottom.src = 'img/building.png';
        images.background.src = 'img/flappybackground.png';
        // Set fullscreen canvas
        function resizeCanvas() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
        window.addEventListener('resize', resizeCanvas);
        resizeCanvas();

        // Game variables
        const bird = {
            x: canvas.width * 0.2,
            y: canvas.height/2,
            width: 100,
            height: 70,
            velocity: 0,
            gravity: 0.3,
            jump: -8
        };

        const pipes = [];
        const pipe = {
            width: 80,
            gap: 200,
            spacing: 300, // Increased horizontal spacing
            speed: 4
        };

        let gameLoopId;
        let score = 0;
        let gameActive = false;

        // Game functions
        function createPipe() {
            const minHeight = 100;
            const maxHeight = canvas.height - pipe.gap - minHeight;
            const height = Math.random() * (maxHeight - minHeight) + minHeight;

            pipes.push({
                x: canvas.width,
                topHeight: height,
                passed: false
            });
        }

        function drawBird() {
            ctx.drawImage(images.bird, bird.x, bird.y, bird.width, bird.height);
        }

        function drawPipes() {
            pipes.forEach(pipeObj => {
                // Top pipe (flipped vertically)
                ctx.save();
                ctx.scale(1, -1);
                ctx.drawImage(images.pipeTop,
                    pipeObj.x,
                    -pipeObj.topHeight,
                    pipe.width,
                    pipeObj.topHeight
                );
                ctx.restore();

                // Bottom pipe
                ctx.drawImage(images.pipeBottom,
                    pipeObj.x,
                    pipeObj.topHeight + pipe.gap,
                    pipe.width,
                    canvas.height - (pipeObj.topHeight + pipe.gap)
                );
            });
        }

        function drawBackground() {
            ctx.drawImage(images.background, 0, 0, canvas.width, canvas.height);
        }

        function updateGame() {
            // Bird physics
            bird.velocity += bird.gravity;
            bird.y += bird.velocity;

            // Pipe movement
            pipes.forEach(pipeObj => {
                pipeObj.x -= pipe.speed;

                // Adjust hitbox to ignore transparent pixels
                let birdHitbox = {
                    x: bird.x + 30, // Shrink width detection (left padding)
                    y: bird.y + 30, // Shrink height detection (top padding)
                    width: bird.width - 40, // Shrink width (right padding)
                    height: bird.height - 60 // Shrink height (bottom padding)
                };

                // Collision detection: Bird fully enters the pipe's area
                if (birdHitbox.x + birdHitbox.width > pipeObj.x && birdHitbox.x < pipeObj.x + pipe.width) {
                    
                    // If bird's visible part is inside the pipe area (not the gap)
                    if (birdHitbox.y < pipeObj.topHeight || birdHitbox.y + birdHitbox.height > pipeObj.topHeight + pipe.gap) {
                        collisionSound.play();
                        endGame();
                    }
                }

                // Score counting
                if (!pipeObj.passed && bird.x > pipeObj.x + pipe.width) {
                    pipeObj.passed = true;
                    score++;
                    scoreDisplay.textContent = `Score: ${score}`;

                    // Check for win condition
                    if (score === 10) {
                        winGame();
                    }
                }
            });



            // Remove off-screen pipes
            if (pipes.length > 0 && pipes[0].x + pipe.width < 0) {
                pipes.shift();
            }

            // Create new pipes
            if (pipes.length === 0 || pipes[pipes.length - 1].x < canvas.width - pipe.spacing) {
                createPipe();
            }

            // Floor/ceiling collision
            if (bird.y + bird.height > canvas.height || bird.y < 0) {
                collisionSound.play();
                endGame();
            }
        }

        // Function to handle the win scenario
        function winGame() {
            gameActive = false;
            cancelAnimationFrame(gameLoopId);
            
            // Stop music
            bgMusic.pause();
            bgMusic.currentTime = 0;

            // Display win message
            gameOverScreen.style.display = 'flex';
            finalScore.textContent = `Congratulations! You Win!`;
            alert("Congratulations! You Win!")
            // Send win message to the parent game
            window.parent.postMessage('win', window.location.origin);
        }


        function drawGame() {
            drawBackground();
            drawPipes();
            drawBird();
        }

        function gameLoop() {
            if (!gameActive) return;
            
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            updateGame();
            drawGame();
            gameLoopId = requestAnimationFrame(gameLoop);
        }

        document.getElementById("autobtn").addEventListener('click',()=>{
            console.log("Hello")
            winGame()
          })
          
        function startGame() {
            // Reset game state
            bird.y = canvas.height / 2;
            bird.velocity = 0;
            pipes.length = 0;
            score = 0;
            gameActive = true;
            
            // UI handling
            startScreen.style.display = 'none';
            gameOverScreen.style.display = 'none';
            scoreDisplay.textContent = 'Score: 0';
            
            // Start music
            bgMusic.play();
            gameLoop();
        }

        function endGame() {
            gameActive = false;
            cancelAnimationFrame(gameLoopId);
            
            // Stop music
            bgMusic.pause();
            bgMusic.currentTime = 0;
            
            // Show game over screen
            gameOverScreen.style.display = 'flex';
            finalScore.textContent = `Final Score: ${score}`;
            window.parent.postMessage('lose', window.location.origin);
        }

        // Event listeners
        document.addEventListener('keydown', e => {
            if (e.code === 'Space') {
                if (gameActive) {
                    bird.velocity = bird.jump;
                    jumpSound.play();
                }
            }
            if (e.code === 'KeyR' && !gameActive) {
                startGame();
            }
        });

        document.getElementById('startButton').addEventListener('click', startGame);
        document.getElementById('restartButton').addEventListener('click', startGame);