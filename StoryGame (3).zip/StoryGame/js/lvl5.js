let currentLevel = 1;
        const horrorMusic = document.getElementById('horrorMusic');
        const screamer = document.getElementById('screamer');
    
        const questions = [
            { question: "The number of the beast?", answer: "666" }, 
            { question: "Where do lost souls go?", answer: "hell" }, 
            { question: "Who lurks in the shadows?", answer: "the reaper" }, 
            { question: "What drink keeps vampires away?", answer: "holy water" }, 
            { question: "What is the forbidden number?", answer: "13" },
        ];
    
        function fetchQuestion() {
            if (currentLevel <= questions.length) {
                document.getElementById('question').innerText = questions[currentLevel - 1].question;
                document.getElementById('level-info').innerText = `Level: ${currentLevel}`;
            } else {
                document.getElementById('question').innerText = "You have unlocked the final truth...";
                document.getElementById('level-info').innerText = "The darkness welcomes you.";
                window.parent.postMessage('win', window.location.origin);
                horrorMusic.pause();
                horrorMusic.currentTime = 0;
                triggerScreamer();
            }
        }
    
        function submitAnswer() {
            const answer = document.getElementById('answer').value.toLowerCase();
            const correctAnswer = questions[currentLevel - 1].answer.toLowerCase();
            const feedback = document.getElementById('feedback');
            
            if (answer === correctAnswer) {
                feedback.innerText = "Correct... but at what cost?";
                feedback.className = 'feedback success';
                currentLevel++;
                fetchQuestion();
            } else {
                feedback.innerText = "Wrong answer. Try again... before it's too late.";
                window.parent.postMessage('lose', window.location.origin);
                // feedback.className = 'feedback error';
            }
            document.getElementById('answer').value = '';
            document.getElementById('answer').focus();
        }
    
        function triggerScreamer() {
            setTimeout(() => {
                screamer.style.top = "0";
                setTimeout(() => {
                    screamer.style.top = "-100%";
                }, 1000);
            }, 2000);
        }
    
        // Event listener for Enter key
        document.getElementById('answer').addEventListener("keypress", function(event) {
            if (event.key === "Enter") {
                submitAnswer();
            }
        });

        document.getElementById("autobtn").addEventListener('click',()=>{
            window.parent.postMessage('win', window.location.origin);          
        })

        horrorMusic.play();
        fetchQuestion();