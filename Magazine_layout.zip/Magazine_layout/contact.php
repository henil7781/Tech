<?php
    $insert = false;
    if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['message'])) {
        $server = "localhost";
        $username = "root";
        $password = "";

        // Create a connection
        $con = mysqli_connect($server, $username, $password);

        // Check for connection success
        if (!$con) {
            die("Connection to this database failed due to " . mysqli_connect_error());
        }

        // Collect POST variables
        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];


        // Check if username and password are empty
        if (empty($name) || empty($email)) {
           echo "<div class='alert alert-danger' style='font-size:30px;'>Name and email cannot be empty.</div>";
           header("refresh:2;url=page5.html"); // Redirect back to signup page after 2 seconds
           exit(); // Terminate script execution
    }
        // SQL query to insert data into the database
        $sql = "INSERT INTO `magazine`.`contacts` (`name`, `email`, `message`, `timestamp`) 
                VALUES ('$name', '$email', '$message', CURRENT_TIMESTAMP());";

        // Execute the query
        if ($con->query($sql) === true) {
            $insert = true;
        } else {
            echo "ERROR: $sql <br> $con->error";
        }

        // Close the database connection
        $con->close();
    }
    if ($insert) {
        echo "<div class='alert alert-success' style='font-size:30px;'>Your message has been sent successfully. Redirecting...</div>";
        header("refresh:2;url=home1.html");  // Redirect back to the contact page after 2 seconds
    }
    else{
        exit();
    }
?>

