let P1 = true; // Human is always X (true), computer is O (false)
    let moves = [];
    let choice = Array(9).fill(null);
    let emptyCells = 9;

    function setButtonsEnabled(enabled) {
      for (let i = 1; i <= 9; i++) {
        document.getElementById("box" + i).disabled = !enabled;
      }
    }

    function resetGame() {
      P1 = true;
      emptyCells = 9;
      moves = [];
      choice = Array(9).fill(null);
      document.getElementById("result").innerHTML = "Your Turn";
      setButtonsEnabled(true);
      for (let i = 1; i <= 9; i++) {
        const button = document.getElementById("box" + i);
        button.innerHTML = "";
      }
    }

    function undoMove() {
      if (moves.length > 0) {
        const idx = moves.pop();
        const button = document.getElementById("box" + idx);
        button.innerHTML = "";
        choice[idx - 1] = null;
        emptyCells++;
        P1 = moves.length % 2 === 0; // Reset turn based on remaining moves
        document.getElementById("result").innerHTML = P1 ? "Your Turn" : "Computer's Turn";
        setButtonsEnabled(P1);
      }
    }

    function box(idx) {
      if (!P1) return; // Ignore clicks during computer's turn
      
      const pos = idx - 1;
      if (choice[pos] === null) {
        // Human move
        const cell = document.getElementById("box" + idx);
        cell.innerHTML = "X";
        choice[pos] = "X";
        moves.push(idx);
        emptyCells--;
        P1 = false;
        document.getElementById("result").innerHTML = "Computer's Turn";
        
        if (!checkResult()) {
          setButtonsEnabled(false);
          setTimeout(computerMove, 500);
        }
      }
    }

    function computerMove() {
      const available = [];
      for (let i = 0; i < choice.length; i++) {
        if (choice[i] === null) available.push(i + 1);
      }
      
      if (available.length > 0) {
        const move = available[Math.floor(Math.random() * available.length)];
        const pos = move - 1;
        const cell = document.getElementById("box" + move);
        
        // Computer move
        cell.innerHTML = "O";
        choice[pos] = "O";
        moves.push(move);
        emptyCells--;
        P1 = true;
        document.getElementById("result").innerHTML = "Your Turn";
        
        checkResult();
        setButtonsEnabled(true);
      }
    }

    function checkResult() {
      const winPatterns = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
        [0, 4, 8], [2, 4, 6] // Diagonals
      ];

      for (const pattern of winPatterns) {
        const [a, b, c] = pattern;
        if (choice[a] && choice[a] === choice[b] && choice[b] === choice[c]) {
          const winner = choice[a] === "X" ? "You Win!" : "Computer Wins!";
          if(winner=="You Win!"){
            window.parent.postMessage('win', window.location.origin);
          }
          else{
            window.parent.postMessage('lose', window.location.origin);
          }
          document.getElementById("result").innerHTML = winner;
          playWinSound();
          setTimeout(resetGame, 2000);
          return true;
        }
      }

      if (emptyCells === 0) {
        document.getElementById("result").innerHTML = "It's a Draw!";
        playTieSound();
        setTimeout(resetGame, 2000);
        return true;
      }
      return false;
    }

    // ... (keep existing audio and popup functions) ...
    let popup = document.getElementById("popup");
    function openPopup() { popup.classList.add("open-popup"); }
    function closePopup() { popup.classList.remove("open-popup"); }

    function playWinSound() { document.getElementById("win").play(); }
    function playTieSound() { document.getElementById("tie").play(); }

    document.getElementById("autobtn").addEventListener('click',()=>{
      window.parent.postMessage('win', window.location.origin);
    })