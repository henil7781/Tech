class LevelQueue {
    constructor(levels) {
        this.queue = this.customShuffle(levels);
        this.front = 0;
        this.end = this.queue.length;
    }

    // Custom shuffle function (no built-in methods used)
    customShuffle(arr) {
        let shuffled = arr.slice(); // Copy the array
        let n = shuffled.length;
        for (let i = 0; i < n - 1; i++) {
            let randIndex = Math.floor(Math.random() * (n - i)) + i;
            let temp = shuffled[i];
            shuffled[i] = shuffled[randIndex];
            shuffled[randIndex] = temp;
        }
        return shuffled;
    }

    // Get next level manually (Queue behavior)
    getNextLevel() {
        if (this.front < this.end) {
            return this.queue[this.front++];
        }
        return null; // If all levels are played
    }
    

    isEmpty() {
        return this.front >= this.end;
    }
}

// Initialize the game state
let gameState = {
    currentLevel: 0,
    character: null,
    storyProgress: 0,
    levelsQueue: new LevelQueue([
        'lvl1.html',
        'lvl2.html',
        'lvl3.html',
        'lvl4.html',
        'lvl5.html'
    ]),
    img: [
        'img/image1.jpg',
        'img/image2.jpg',
        'img/img3.png',
        'img/img4.png'
    ]
};

const storyTemplate = [
    "November 2023... {character} stares at his empty bank account, hands trembling...",
    "The weight of $200 billion in losses crushes his soul. A pistol sits on the desk...",
    "Suddenly, a shadowy figure appears: 'Play my games - win back your fortune!'",
    "'But be warned... one loss means THE END!'",
    // **Level 1**
    "The first challenge appears. A single candle flickers in the dark. A whisper in the shadows hisses: 'Answer correctly, or be consumed by the abyss…'",

    // **Level 2**
    "You survive… for now. The air grows colder. A door creaks open to reveal an endless corridor, lined with faces frozen in eternal screams. 'They failed. Will you?' the voice taunts.",

    // **Level 3**
    "The walls begin to bleed. The ground beneath trembles as clawed hands reach from below. 'A step forward… or an eternal fall?' The choice is yours.",

    // **Level 4**
    "The figure reveals its true form—a towering entity with hollow eyes and a grin stitched with shadows. 'You have done well… but you face me now. I am the Architect of Ruin.'",

    // **Final Level - Victory**
    "Darkness implodes. The world bends and twists as reality shatters. You stand victorious, but a voice whispers from nowhere: 'You win today… but I will return. The next game is against the God of Hell…' ",

    // **Secret Ending (If you win again)**
    "The flames of hell rage around you. A monstrous deity looms, its laughter shaking the void. But you… you defy fate. You strike, and the unthinkable happens…",
    
    // **Final Revelation**
    "Silence. The god of hell is no more. The void watches, waiting. And then—'Congratulations, mortal. You are now… the new ruler of darkness.'"
];

function ReNew() {
    localStorage.removeItem("gameState");
    location.reload();
}

document.addEventListener("DOMContentLoaded", () => {
    loadGameState();
    if (gameState.storyProgress > 0 || gameState.currentLevel > 0) {
        document.getElementById("continue-btn").style.display = "block";
    }
});

function saveGameState() {
    localStorage.setItem("gameState", JSON.stringify(gameState));
}

function loadGameState() {
    const savedState = localStorage.getItem("gameState");
    if (savedState) {
        gameState = JSON.parse(savedState);
    }
}

function showCharacterSelect() {
    document.getElementById('main-menu').style.display = 'none';
    document.getElementById('character-selection').style.display = 'grid';
    localStorage.removeItem("gameState");
}

function selectCharacter(char) {
    gameState.character = char;
    gameState.currentLevel = 0;
    gameState.storyProgress = 0;
    document.getElementById('character-selection').style.display = 'none';
    document.getElementById('story-container').style.display = 'block';
    progressStory();
}

function progressStory() {
    const storyElement = document.getElementById('story-text');
    if (gameState.storyProgress < 5) {
        let storyLine = storyTemplate[gameState.storyProgress].replace('{character}', gameState.character);
        
        document.body.style.backgroundImage = `url('${gameState.img[gameState.storyProgress]}')`;
        document.body.style.transition = 'background-image 1.5s ease-out, opacity 1s';

        document.body.style.backgroundSize = "contain";  // Ensure full image is visible
        document.body.style.backgroundPosition = "center"; // Center the image
        document.body.style.backgroundRepeat = "no-repeat"; // No repeating
        document.body.style.height = "100vh"; // Full viewport height
        document.body.style.width = "100vw"; // Full viewport width
        document.body.style.display = "flex"; // Flexbox to center content
        document.body.style.justifyContent = "center"; // Center horizontally
        document.body.style.alignItems = "end"; // Center vertically
        document.body.style.margin = "0";
        document.body.style.padding = "0";

        storyElement.innerHTML = "";
        animateText(storyLine);
        gameState.storyProgress++;
        saveGameState();
    } else {
        startNextLevel();
    }
}

function animateText(text) {
    let index = 0;
    const storyElement = document.getElementById('story-text');
    storyElement.innerHTML = '';
    const interval = setInterval(() => {
        storyElement.innerHTML += text[index];
        index++;
        if (index >= text.length) clearInterval(interval);
    }, 40);
}

function continueGame() {
    document.getElementById("main-menu").style.display = "none";
    if (gameState.storyProgress < storyTemplate.length) {
        document.getElementById("story-container").style.display = "block";
        progressStory();
    } else {
        startNextLevel();
    }
}

function startNextLevel() {
    if (!gameState.levelsQueue.isEmpty()) {
        let nextGame = gameState.levelsQueue.getNextLevel();
        if (nextGame) {
            document.getElementById('story-container').style.display = 'none';
            document.getElementById('game-container').style.display = 'block';
            document.getElementById('game-iframe').src = nextGame;
            saveGameState();
        } else {
            alert("You have completed all levels!");
            window.location.href = 'congo.html'; // Redirect to a winning screen
        }
    } else {
        alert("No more levels left!");
        window.location.href = 'congo.html';
    }
}


function gameLost() {
    alert(gameState.character + "'s journey has ended...");
    localStorage.removeItem("gameState");
    location.reload();
}

window.addEventListener('message', function(event) {
    if (event.origin !== window.location.origin) {
        console.warn("Message origin not verified:", event.origin);
        return;
    }

    console.log("Received message:", event.data);

    if (event.data === 'win') {
        gameState.currentLevel++;
        saveGameState();

        if (!gameState.levelsQueue.isEmpty()) {
            // Show the story before transitioning
            document.getElementById('story-container').style.display = 'block';
            document.getElementById('game-container').style.display = 'none';
            document.body.style.backgroundImage = "url('img/img5.png')";
            
            animateText(storyTemplate[gameState.storyProgress], () => {
                gameState.storyProgress++;
                saveGameState();
                startNextLevel(); // Start next level AFTER story plays
            });
        } else {
            alert("You completed all levels!");
            window.location.href = 'congo.html';
        }
    } else if (event.data === 'lose') {
        gameLost();
    }
});
